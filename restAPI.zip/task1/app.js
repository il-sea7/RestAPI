require('dotenv').config();

const express = require('express');
const app = express();

const port = process.env.PORT || 5000;
const url = process.env.DATABASE_CONN_URL;

const mongoose = require('mongoose');
mongoose.connect(url, {useNewUrlParser:true, useUnifiedTopology:true});
const selectedDB = mongoose.connection;
selectedDB.on('error', ()=>{
    console.log('Error');
});
selectedDB.once('open', ()=>{ 
    console.log('Connnected');
});

app.use(express.json());

app.listen(port, ()=>{
    console.log('Listening on port', port);
});

const victimsRouter = require('./routes/victims');
app.use('/victims', victimsRouter);

