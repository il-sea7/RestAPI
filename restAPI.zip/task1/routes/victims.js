const express = require('express');
const victimsRouter = express.Router();

const Victim =  require('../models/victim');

victimsRouter.get('/', async (req, res)=>{
   try{

    const retreivedVictims = await Victim.find();
    res.json(retreivedVictims)
    console.log('Viewed Victims!')


   }catch(error){
    res.json({message: error.message});
   }
});

victimsRouter.get('/:id', async (req, res)=>{
    try{
        let requestedVictimID = req.params.id;
 
     const retreivedVictim = await Victim.findById(requestedVictimID);

     if (retreivedVictim){
        res.json(retreivedVictim)
        console.log('View Victim!')


     } else{
         res.json({message: 'The victim with ID ' + requestedVictimID + 'does not exist'})
     }
 
    }catch(error){
     res.json({message: error.message});
    }
 });

 victimsRouter.post('/add', async (req, res) => {
    const victimToAdd = new Victim({
        victimName: req.body.victimName, 
        ngo: req.body.ngo,
        hasMedicalAid: req.body.hasMedicalAid,
        nextOfKin: req.body.nextOfKin
    });
    try{
       let addedVictim = await victimToAdd.save();
       res.json(addedVictim);
       console.log('Added victim!')

    }catch(error){
        res.json({message: error.message});
    }

 });


 victimsRouter.patch('/:id', async (req, res) => {
    try {
        const updateVictim = await Victim.findByIdAndUpdate(req.params.id, req.body, {
        new: true,
         runValidators: true
        });

        res.json(updateVictim);
        console.log('Updated victim!');
       } catch (error) {
        res.json({message: error.message});
    }
 })


 victimsRouter.delete('/:id', async (req, res) => {
     try {
         await Victim.findByIdAndDelete({_id: req.params.id}).then((victim)=> {
            res.json(victim);
            console.log('Deleted victim!');
         })

     }catch (error) {
        res.json({message: error.message});
    }
    
 })


module.exports = victimsRouter;