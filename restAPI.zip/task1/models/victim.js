const mongoose = require('mongoose');

const victimSchema = new mongoose.Schema(
    {
        victimName:{
            type: String,
            required: true
        },
        ngo:{
            type: String,
            enum: ['Oxfam', 'Care', 'PIH'],
            required: true
        },
        hasMedicalAid:{
            type: Boolean,
            default: false,
            required: true
        },
        nextOfKin:{
            type: Number,
            required: true
        } 

    }

);

module.exports = mongoose.model('Victims',victimSchema)