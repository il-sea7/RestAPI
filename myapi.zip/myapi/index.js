const express = require('express');
const app = express();
const Joi = require('@hapi/joi');


app.use(express.json());

const fruits = [
    {name: 'Apples', id: 1},
    {name: 'Banana', id: 2},
    {name: 'Cherries', id: 3},
    {name: 'Dates', id: 4},
    {name: 'Grapes', id: 5},
    {name: 'Lemons', id: 6},
    {name: 'Melons', id: 7}
];
//Read Request Handlers
app.get('/', function(req, res){
    res.send('Join our mailing list for free course coupons: http://bluelimelearningsolutions.com/')
});

app.get('/api/fruits', function(req, res){
    res.send(fruits);
});

app.get('/api/fruits/:id', function(req, res){
    const fruit = fruits.find(c => c.id === parseInt(req.params.id));
    if(!fruit)res.status(404).send('fruit not found');
    res.send(fruit);
});
//Create Request Handler
app.post('/api/fruits', function(req, res){
    const {error} = validateFruits(req.body);
    if(error){
        res.status(400).send(error.details[0].message);
        return;
    }
    const fruit = {
        id: fruits.length +1,
        name: req.body.name
    };
    fruits.push(fruit);
    res.send(fruit);
});

//Update Request Handler (put used to update)
app.put('/api/fruits/:id', function(req, res){
    const fruit = fruits.find(c => c.id === parseInt(req.params.id));
    if(!fruit) res.status(404).send('Fruit not found');

    const {error} = validateFruits(req.body);
    if(error){
        res.status(400).send(error.details[0].message);
        return;
    }
    fruit.name  = req.body.name;
    res.send(fruit);
});

//Delete Request Handler
app.delete('/api/fruits/:id', function(req, res){
    const fruit = fruits.find(c => c.id === parseInt(req.params.id));
    if(!fruit) res.status(404).send('Fruit not found');
    const index = fruits.indexOf(fruit);
    fruits.splice(index,1);
    res.send(fruit);
});

function validateFruits(fruit){
    const schema = Joi.object({name: Joi.string().min(3).required()});
    const validation = schema.validate(fruit);
    return validation;
}


/*
function validateFruits(fruit){
    const schema = {
        name: Joi.string().min(3).required()
    };
    return Joi.validate(fruit, schema);
}
*/

const port = process.env.PORT || 5001;
app.listen(port, ()=> console.log(`listening on port ${port}`));